/**
 * RAMP Extension — Popup UI v2
 *
 * Avatar Control Dashboard with safe execution pipeline.
 * Shows: stats, execution state, today's plan, needs review, pending drafts.
 * Auto-refreshes every 30s while popup is open.
 */

import { isAuthenticated, getAuth } from '../shared/auth.js';

const REFRESH_INTERVAL = 30_000;

async function init() {
  const authenticated = await isAuthenticated();
  if (!authenticated) {
    window.location.href = 'onboarding.html';
    return;
  }

  await refreshAll();
  setInterval(refreshAll, REFRESH_INTERVAL);
}

async function refreshAll() {
  await detectAndShowAccount();
  await fetchDashboard();
  await fetchExecutionState();
  await fetchQueue();
  await fetchStatus();
}

// ─── Account Detection ─────────────────────────────────────────────────────

async function detectAndShowAccount() {
  const usernameEl = document.getElementById('account-username');
  const badgeReddit = document.getElementById('badge-reddit');
  const badgeRamp = document.getElementById('badge-ramp');

  let redditUsername = null;
  try {
    const stored = await chrome.storage.local.get('activeRedditUsername');
    redditUsername = stored?.activeRedditUsername || null;
  } catch {}

  if (!redditUsername) {
    try {
      const tabs = await chrome.tabs.query({ url: ['https://www.reddit.com/*', 'https://old.reddit.com/*'] });
      for (const tab of tabs) {
        try {
          const resp = await chrome.tabs.sendMessage(tab.id, { type: 'GET_USERNAME' });
          if (resp?.username) {
            redditUsername = resp.username;
            await chrome.storage.local.set({ activeRedditUsername: redditUsername });
            break;
          }
        } catch { continue; }
      }
    } catch {}
  }

  const auth = await getAuth();
  const authUsername = auth?.avatarUsername || null;
  const finalUsername = redditUsername || authUsername;

  if (finalUsername) {
    usernameEl.textContent = `u/${finalUsername}`;
    badgeReddit.textContent = redditUsername ? 'Reddit: ✓' : 'Reddit: ✗';
    badgeReddit.className = `status-badge ${redditUsername ? 'badge--ok' : 'badge--err'}`;
  } else {
    usernameEl.textContent = 'No account detected';
    badgeReddit.textContent = 'Reddit: ✗';
    badgeReddit.className = 'status-badge badge--err';
  }

  const hasAuth = auth?.token && auth?.rampUrl;
  badgeRamp.textContent = hasAuth ? 'RAMP: ✓' : 'RAMP: ✗';
  badgeRamp.className = `status-badge ${hasAuth ? 'badge--ok' : 'badge--err'}`;
}

// ─── Execution State (primary panel) ───────────────────────────────────────

async function fetchExecutionState() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_EXECUTION_STATE' });
    renderExecutionState(response?.state || null);
  } catch {
    renderExecutionState(null);
  }
}

function renderExecutionState(state) {
  const container = document.getElementById('exec-content');

  if (!state) {
    container.innerHTML = '<p class="empty-text">No active execution</p>';
    return;
  }

  const { status, task, proof, error, tab_id, finished_at } = state;

  if (status === 'preparing') {
    container.innerHTML = `
      <div class="exec-active">
        <div class="exec-status exec-status--preparing">⏳ Preparing...</div>
        <div class="exec-detail">
          <span class="exec-sub">r/${esc(task?.subreddit || '?')}</span>
          <span class="exec-title">${esc(truncate(task?.thread_title || '', 50))}</span>
        </div>
        <div class="exec-steps">
          <div class="exec-step">◻ Opening thread...</div>
        </div>
      </div>
    `;
    return;
  }

  if (status === 'prepared' && proof) {
    container.innerHTML = `
      <div class="exec-active">
        <div class="exec-status exec-status--prepared">✅ Ready to Publish</div>
        <div class="exec-proof">
          <div class="proof-item ${proof.thread_opened ? 'proof--ok' : 'proof--fail'}">
            ${proof.thread_opened ? '✓' : '✗'} Thread opened
          </div>
          <div class="proof-item ${proof.editor_found ? 'proof--ok' : 'proof--fail'}">
            ${proof.editor_found ? '✓' : '✗'} Editor found
          </div>
          <div class="proof-item ${proof.text_inserted ? 'proof--ok' : 'proof--fail'}">
            ${proof.text_inserted ? '✓' : '✗'} Text inserted (${proof.char_count} chars)
          </div>
          <div class="proof-item ${proof.text_matches ? 'proof--ok' : 'proof--fail'}">
            ${proof.text_matches ? '✓' : '✗'} Content verified
          </div>
          <div class="proof-item ${proof.submit_available ? 'proof--ok' : 'proof--warn'}">
            ${proof.submit_available ? '✓' : '⚠'} Submit button ${proof.submit_available ? 'found' : 'not found'}
          </div>
          <div class="proof-item proof--safe">
            ✗ Not published
          </div>
        </div>
        <div class="exec-actions">
          <button class="exec-btn exec-btn--open" id="btn-open-reddit" data-task-id="${task?.task_id}">
            Open in Reddit
          </button>
          <button class="exec-btn exec-btn--cancel" id="btn-cancel-prepared" data-task-id="${task?.task_id}">
            Cancel
          </button>
        </div>
        <div class="exec-meta">
          r/${esc(task?.subreddit || '?')} • ${esc(truncate(task?.thread_title || '', 40))}
        </div>
      </div>
    `;

    // Bind buttons
    document.getElementById('btn-open-reddit')?.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'OPEN_TASK_TAB', taskId: task?.task_id });
    });
    document.getElementById('btn-cancel-prepared')?.addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'CANCEL_PREPARED_TASK', taskId: task?.task_id });
      await fetchExecutionState();
    });
    return;
  }

  if (status === 'failed') {
    container.innerHTML = `
      <div class="exec-active">
        <div class="exec-status exec-status--failed">❌ Failed</div>
        <div class="exec-error">${esc(error || 'Unknown error')}</div>
        <div class="exec-meta">
          r/${esc(task?.subreddit || '?')} • ${esc(truncate(task?.thread_title || '', 40))}
        </div>
        <div class="exec-actions">
          <button class="exec-btn exec-btn--cancel" id="btn-dismiss-error" data-task-id="${task?.task_id}">
            Dismiss
          </button>
        </div>
      </div>
    `;
    document.getElementById('btn-dismiss-error')?.addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'CANCEL_PREPARED_TASK', taskId: task?.task_id });
      await fetchExecutionState();
    });
    return;
  }

  // Unknown state
  container.innerHTML = '<p class="empty-text">No active execution</p>';
}

// ─── Dashboard (backend data: stats, EPG, drafts) ─────────────────────────

async function fetchDashboard() {
  const auth = await getAuth();
  if (!auth?.token || !auth?.rampUrl) return;

  let username = auth.avatarUsername || '';
  if (!username) {
    const stored = await chrome.storage.local.get('activeRedditUsername');
    username = stored?.activeRedditUsername || '';
    if (username && auth.token) {
      await chrome.storage.local.set({ ramp_auth: { ...auth, avatarUsername: username } });
    }
  }
  if (!username) return;

  const url = `${auth.rampUrl}/api/extension/dashboard?avatar_username=${encodeURIComponent(username)}`;

  try {
    const resp = await fetch(url, {
      headers: { 'Authorization': `Bearer ${auth.token}` },
    });
    if (!resp.ok) return;
    const data = await resp.json();
    renderStats(data.stats);
    renderDrafts(data.pending_drafts, data.links);
    renderEPG(data.epg, data.links);
    renderLastUpdated(data.last_updated);
  } catch (err) {
    console.error('[RAMP] Dashboard fetch error:', err);
  }
}

function renderStats(stats) {
  if (!stats) return;
  document.getElementById('stat-posts').textContent = stats.posts_today;
  document.getElementById('stat-karma').textContent = stats.karma_7d > 0 ? `+${stats.karma_7d}` : stats.karma_7d;
  document.getElementById('stat-cqs').textContent = (stats.cqs_level || '?').toUpperCase();
  document.getElementById('stat-phase').textContent = stats.phase ?? '?';

  const cqsEl = document.getElementById('stat-cqs');
  cqsEl.className = 'stat-value stat-cqs--' + (stats.cqs_level || 'unknown');
}

function renderDrafts(drafts, links) {
  const list = document.getElementById('drafts-list');
  const count = document.getElementById('drafts-count');
  const linkEl = document.getElementById('link-review');

  count.textContent = drafts?.length || 0;
  if (links?.review_queue) linkEl.href = links.review_queue;

  if (!drafts || drafts.length === 0) {
    list.innerHTML = '<p class="empty-text">No pending drafts</p>';
    return;
  }

  list.innerHTML = drafts.map(d => `
    <div class="mini-card">
      <div class="mini-card__top">
        <span class="mini-card__sub">r/${esc(d.subreddit)}</span>
        <a href="${esc(d.approve_url)}" target="_blank" class="mini-card__action">Review →</a>
      </div>
      <div class="mini-card__title">${esc(d.thread_title || d.text_preview)}</div>
    </div>
  `).join('');
}

function renderEPG(slots, links) {
  const list = document.getElementById('epg-list');
  const count = document.getElementById('epg-count');
  const linkEl = document.getElementById('link-epg');

  count.textContent = slots?.length || 0;
  if (links?.epg_page) linkEl.href = links.epg_page;

  if (!slots || slots.length === 0) {
    list.innerHTML = '<p class="empty-text">No slots today</p>';
    return;
  }

  list.innerHTML = slots.map(s => {
    const time = s.scheduled_at ? new Date(s.scheduled_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—';
    const statusClass = `epg-status--${s.status}`;
    return `
      <div class="epg-row">
        <span class="epg-row__time">${time}</span>
        <span class="epg-row__sub">r/${esc(s.subreddit)}</span>
        <span class="epg-row__status ${statusClass}">${s.status}</span>
      </div>
    `;
  }).join('');
}

function renderLastUpdated(ts) {
  if (!ts) return;
  const el = document.getElementById('last-updated');
  const time = new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  el.textContent = `Updated ${time}`;
}

// ─── Task Queue (Needs Review) ─────────────────────────────────────────────

async function fetchQueue() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_QUEUE' });
    const tasks = response?.tasks || [];
    renderTaskQueue(tasks);
  } catch {
    renderTaskQueue([]);
  }
}

function renderTaskQueue(tasks) {
  const container = document.getElementById('task-queue');
  const count = document.getElementById('queue-count');
  const emptyState = document.getElementById('empty-state');

  container.querySelectorAll('.task-card').forEach(c => c.remove());
  count.textContent = tasks.length;

  if (tasks.length === 0) {
    if (emptyState) emptyState.style.display = '';
    return;
  }
  if (emptyState) emptyState.style.display = 'none';

  tasks.forEach(task => {
    const isDiagnostic = task.priority === 'diagnostic';
    const time = task.scheduled_at
      ? new Date(task.scheduled_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : 'ASAP';

    const card = document.createElement('div');
    card.className = `task-card ${isDiagnostic ? 'task-card--diagnostic' : 'task-card--content'}`;
    card.dataset.taskId = task.task_id;
    card.innerHTML = `
      <div class="task-card__header">
        <span class="task-card__subreddit">r/${esc(task.subreddit || '')}</span>
        <span class="task-card__time">${time}</span>
      </div>
      <div class="task-card__title">${esc(truncate(task.thread_title || '', 60))}</div>
      <div class="task-card__preview">${esc(truncate(task.comment_text || '', 80))}</div>
      <div class="task-card__actions">
        ${isDiagnostic
          ? '<span class="task-card__auto-badge">Auto</span>'
          : `<button class="task-card__btn task-card__btn--prepare" data-id="${task.task_id}">Prepare</button>
             <button class="task-card__btn task-card__btn--reject" data-id="${task.task_id}">Skip</button>`
        }
      </div>
    `;
    container.appendChild(card);
  });

  // Bind Prepare buttons
  container.querySelectorAll('.task-card__btn--prepare').forEach(btn => {
    btn.addEventListener('click', () => handlePrepare(btn.dataset.id));
  });
  container.querySelectorAll('.task-card__btn--reject').forEach(btn => {
    btn.addEventListener('click', () => handleReject(btn.dataset.id));
  });

  // Update badge
  chrome.action.setBadgeText({ text: tasks.length > 0 ? String(tasks.length) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#0f3460' });
}

async function handlePrepare(taskId) {
  await chrome.runtime.sendMessage({ type: 'PREPARE_TASK', taskId });
  // Immediate refresh to show "preparing..." state
  setTimeout(async () => {
    await fetchExecutionState();
    await fetchQueue();
  }, 500);
}

async function handleReject(taskId) {
  await chrome.runtime.sendMessage({ type: 'REJECT_TASK', taskId });
  await fetchQueue();
}

// ─── Connection Status ─────────────────────────────────────────────────────

async function fetchStatus() {
  const auth = await getAuth();
  if (!auth?.token || !auth?.rampUrl) {
    setConnectionUI('disconnected', 'Not configured');
    return;
  }

  const statPosts = document.getElementById('stat-posts')?.textContent;
  if (statPosts && statPosts !== '—' && statPosts !== '?') {
    setConnectionUI('connected', 'Connected');
    return;
  }

  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_STATUS' });
    setConnectionUI(response?.status || 'disconnected', response?.statusText || 'Disconnected');
  } catch {
    setConnectionUI('disconnected', 'Disconnected');
  }
}

function setConnectionUI(status, text) {
  const dot = document.getElementById('status-dot');
  const stText = document.getElementById('status-text');
  dot.className = `popup__status-dot popup__status-dot--${status}`;
  stText.textContent = text;
}

// ─── Helpers ───────────────────────────────────────────────────────────────

function esc(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function truncate(str, max) {
  return str.length <= max ? str : str.slice(0, max).trimEnd() + '…';
}

document.addEventListener('DOMContentLoaded', init);
